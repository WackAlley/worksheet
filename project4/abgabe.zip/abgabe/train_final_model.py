import torch
import time
import re
import string
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformer import Transformer
from torch.utils.data import random_split
from icecream import ic

#import torch.optim as optim
from torch.optim import lr_scheduler, SGD, Adam
import pandas as pd


def alibi_positional_encoding(n_heads,sequence_length):
    '''
    ALiBi positional encoding gemäß Vorlesung
    '''
    rel_dist = torch.arange(0, sequence_length).view(1, 1, sequence_length) - torch.arange(0, sequence_length).view(1, sequence_length, 1)
    #slopes = torch.tensor([1.0 / (2.0 ** (h * 1.0 / n_heads)) for h in range(n_heads)])
    slopes = 1.0 / (2.0 ** (torch.arange(n_heads, dtype=torch.float32) / n_heads))
    biases = -slopes.view(n_heads, 1, 1) * rel_dist.abs()
    ALiBi_tensor = biases.exp()
    return ALiBi_tensor


def read_in(file_path):
    with open(file_path,'r', encoding="utf-8") as file:\
        text = file.read()
    #sustitute non standard characters
    cleaned_text = text.replace(r'’', r"'").replace(r'”', r'"').replace(r'«', r'"').replace(r'»', r'"')
    ignore_chars = r"#$%&'*+/<=>@[\]^_`{|}~" + '\n' + r'\\'   # möglicherweise erlauben: !"':;?

    non_german_chars = "ÇÈàâèéêëòóùû"
    #remove words with non german characters and all ignore chars
    cleaned_text = re.sub(rf'(\b\w*[{non_german_chars}]\w*\b|[{ignore_chars}])', ' ', cleaned_text) # remove words with: ÇÈàâèéêëòóùû
    cleaned_text = re.sub(r' +', ' ', cleaned_text) # one or more ' ' replaced by one
    return cleaned_text

class character_ecode_decode():
    def __init__(self, full_text):
        self.vocab = sorted(set(full_text))  # Liste aller einzigartigen Zeichen im Text
        self.char_to_idx, self.idx_to_char = self.generate_lookup_tables(self.vocab)

    def generate_lookup_tables(self, vocab):
        char_to_idx = {char: idx for idx, char in enumerate(vocab)}
        idx_to_char = {idx: char for idx, char in enumerate(vocab)}
        return char_to_idx, idx_to_char

    def encode(self, text):
        return [self.char_to_idx[char] for char in text]

    def decode(self, indeces):
        return  ''.join([self.idx_to_char[idx.item()] for idx in indeces])


# Dataset erstellen
class CharDataset(Dataset):
    def __init__(self, encoded_text, seq_length):
        self.encoded_text = encoded_text
        self.seq_length = seq_length

    def __len__(self):
        return len(self.encoded_text) - self.seq_length

    def __getitem__(self, idx):
        input_seq = self.encoded_text[idx:idx + self.seq_length]
        target_seq = self.encoded_text[idx + 1:idx + self.seq_length + 1]  # Vorhersage ist das nächste Zeichen
        return torch.tensor(input_seq), torch.tensor(target_seq)


def train_one_epoch(train_dataloader, optimizer, loss_criterion, scheduler = None ):
    model.train()  # training mode
    for batch_number, (input_seq, target_seq) in enumerate(train_dataloader):
        ##########
        input_seq = input_seq.to(device)
        target_seq = target_seq.to(device)

        input_seq = model.one_hot_encode(input_seq).to(device)
        target_seq = model.one_hot_encode(target_seq).to(device)
        optimizer.zero_grad()

        # forward
        #ic(input_seq.size())
        output = model(input_seq)
        # loss
        loss = loss_criterion(output.view(-1), target_seq.view(-1))
        #running_loss += loss.item()
        # backward
        loss.backward()
        optimizer.step()
        if scheduler != None:
            scheduler.step()
        if batch_number % 1_000 == 999:
            print(f"progress: {batch_number / len(train_dataloader)} % of current_epoch")
        ##########



def test(test_dataloader, loss_criterion):
    model.eval()  # Gewichte eingefrohren, nicht mehr lernen
    running_loss = 0
    correct = 0
    for batch_id, (input_seq, target_seq) in enumerate(test_dataloader):
        input_seq = input_seq.to(device)
        target_seq = target_seq.to(device)

        input_seq_embedded = model.one_hot_encode(input_seq).to(device)
        target_seq_embedded = model.one_hot_encode(target_seq).to(device)
        # print(data.size())
        #ic(input_seq.size())
        #ic(test_dataloader)
        out = model(input_seq_embedded)
        target_seq = target_seq.to(out.device)
        running_loss += loss_criterion(out, target_seq_embedded).item()
        correct += (torch.argmax(out, dim=-1) == target_seq).sum().item() # Todo: for one hot vectors only
        #correct += (out == target_seq).all(dim=-1).all(dim=-1).sum().item()
    # print('avarage loss: ', loss / len(test_data.dataset))
    # print('accuracy: ', 100. * correct / len(test_data.dataset))
    sequence_length = dataset[1][0].size(-1)
    return 100. * (correct / (len(test_dataloader.dataset) * sequence_length)), running_loss

if __name__ == "__main__":
    file_path = "goe_full.txt"
    full_text = read_in(file_path)
    #seq_length = 16
    seq_length = 256
    batch_size = 128
    encoder = character_ecode_decode(full_text)
    encoded_text = encoder.encode(full_text)

    output_dir = "out"
    ic()

    lr_schedule = "OneCycleLR"
    # Hyperparameter
    embed_size = len(encoder.vocab)
    n_heads = 8
    num_epochs = 7
    attention_type = 'dot_product'
    net_expansion_factor = 4
    n_layers = 12
    learning_rate = 5e-4
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    loss_criterion = nn.CrossEntropyLoss()
    causal_padding_mask = torch.tril(torch.ones((seq_length, seq_length)))
    #masks = [causal_padding_mask]
    mask = causal_padding_mask.to(device)

    # for quick testing: use only a small percentage of all data
    dataset = CharDataset(encoded_text[0:int(len(encoded_text) / 1)], seq_length)  # first 20%, first 1% of the data
    # Split the dataset into 90% training and 10% test data
    train_size = int(0.9 * len(dataset))
    test_size = len(dataset) - train_size
    train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=True)
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    #ic(next(iter(train_dataloader))[0].size())

    start = time.time()
    losses_dict = {}
    accuracy_dict = {}

    #training
    alibi_positional_encoding_tensor = alibi_positional_encoding(n_heads, seq_length).to(device)
    model = Transformer(
        embedding_dim=embed_size,
        num_layers=n_layers,
        n_heads=n_heads,
        device=device,
        net_expansion_factor=net_expansion_factor,
        attention_type=attention_type,
        alibi_bias=alibi_positional_encoding_tensor,
        mask=mask
    ).to(device)
    # Modell, Loss und Optimizer
    optimizer = Adam(model.parameters(), lr=learning_rate)
    total_steps = len(train_dataloader) * num_epochs  # Gesamtanzahl der Schritte
    scheduler = lr_scheduler.OneCycleLR(optimizer, max_lr=learning_rate, total_steps=total_steps)

    tag = f'{type(model).__name__},lr_schedule={lr_schedule}, loss_criterion={loss_criterion}, net_expansion_factor={net_expansion_factor}, n_layers={n_layers}, n_heads={n_heads}, attention_type={attention_type}, lr={learning_rate}, OneCycleLR, mask {"yes" if mask is not None else "no"}'
    print(tag)
    losses_dict[tag] = []
    accuracy_dict[tag] = []

    best = 0
    for epoch in range(1, num_epochs + 1):
        #train_dat_loader, optimizer, loss_criterion, alibi_bias = alibi_positional_encoding_tensor, mask = mask, scheduler = scheduler
        train_one_epoch(train_dataloader,
                        optimizer,
                        loss_criterion,
                        scheduler = scheduler)
        accuracy, loss = test(test_dataloader,
                            loss_criterion)
        losses_dict[tag].append(loss)
        accuracy_dict[tag].append(accuracy)
        if accuracy > best:
            best = accuracy
        print('Accuracy of current epoch: ', accuracy)
    print('Highest accuracy: ', best)
    torch.save(model.state_dict(), f"{output_dir}/{tag}.pt")

    end = time.time()
    print('benötigte Zeit: ', end - start, '\n')

    losses_df = pd.DataFrame.from_dict(losses_dict)
    accuracy_df = pd.DataFrame.from_dict(accuracy_dict)
    losses_df.to_csv("loss.csv")
    accuracy_df.to_csv("accuracy.csv")
    #probabilities = torch.softmax(logits, dim=-1)
