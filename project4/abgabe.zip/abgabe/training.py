import torch
import time

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from encoding_decoding import read_in
from transformer import Transformer
from torch.utils.data import random_split
from icecream import ic

#import torch.optim as optim
from torch.optim import lr_scheduler, SGD, Adam
import pandas as pd

def alibi_positional_encoding(n_heads,sequence_length):
    rel_dist = torch.arange(0, sequence_length).view(1, 1, sequence_length) - torch.arange(0, sequence_length).view(1, sequence_length, 1)
    #slopes = torch.tensor([1.0 / (2.0 ** (h * 1.0 / n_heads)) for h in range(n_heads)])
    slopes = 1.0 / (2.0 ** (torch.arange(n_heads, dtype=torch.float32) / n_heads))
    biases = -slopes.view(n_heads, 1, 1) * rel_dist.abs()
    ALiBi_tensor = biases.exp()
    return ALiBi_tensor


class character_ecode_decode():
    def __init__(self, full_text):
        self.vocab = sorted(set(full_text))  # Liste aller einzigartigen Zeichen im Text
        self.char_to_idx, self.idx_to_char = self.generate_lookup_tables(self.vocab)

    def generate_lookup_tables(self, vocab):
        char_to_idx = {char: idx for idx, char in enumerate(vocab)}
        idx_to_char = {idx: char for idx, char in enumerate(vocab)}
        return char_to_idx, idx_to_char

    def encode(self, text):
        return [self.char_to_idx[char] for char in text]

    def decode(self, indeces):
        return  ''.join([self.idx_to_char[idx.item()] for idx in indeces])


# Dataset erstellen
class CharDataset(Dataset):
    def __init__(self, encoded_text, seq_length):
        self.encoded_text = encoded_text
        self.seq_length = seq_length

    def __len__(self):
        return len(self.encoded_text) - self.seq_length

    def __getitem__(self, idx):
        input_seq = self.encoded_text[idx:idx + self.seq_length]
        target_seq = self.encoded_text[idx + 1:idx + self.seq_length + 1]  # Vorhersage ist das nächste Zeichen
        return torch.tensor(input_seq), torch.tensor(target_seq)


def train_one_epoch(train_dataloader, optimizer, loss_criterion, scheduler = None ):
    model.train()  # training mode
    for batch_number, (input_seq, target_seq) in enumerate(train_dataloader):
        ##########
        input_seq = model.one_hot_encode(input_seq)
        target_seq = model.one_hot_encode(target_seq)
        optimizer.zero_grad()

        # forward
        #ic(input_seq.size())
        output = model(input_seq)
        # loss
        loss = loss_criterion(output.view(-1), target_seq.view(-1))
        #running_loss += loss.item()
        # backward
        loss.backward()
        optimizer.step()
        if scheduler != None:
            scheduler.step()
        if batch_number % 1_000 == 999:
            print(f"progress: {batch_number / len(train_dataloader)} % of current_epoch")
        ##########



def test(test_dataloader, loss_criterion):
    model.eval()  # Gewichte eingefrohren, nicht mehr lernen
    running_loss = 0
    correct = 0
    for batch_id, (input_seq, target_seq) in enumerate(test_dataloader):
        input_seq_embedded = model.one_hot_encode(input_seq)
        target_seq_embedded = model.one_hot_encode(target_seq)
        # print(data.size())
        #ic(input_seq.size())
        #ic(test_dataloader)
        out = model(input_seq_embedded)
        running_loss += loss_criterion(out, target_seq_embedded).item()
        correct += (torch.argmax(out, dim=-1) == target_seq).sum().item() # Todo: for one hot vectors only
        #correct += (out == target_seq).all(dim=-1).all(dim=-1).sum().item()
    # print('avarage loss: ', loss / len(test_data.dataset))
    # print('accuracy: ', 100. * correct / len(test_data.dataset))
    sequence_length = dataset[1][0].size(-1)
    return 100. * (correct / (len(test_dataloader.dataset) * sequence_length)), running_loss

if __name__ == "__main__":
    file_path = "goe_full.txt"
    full_text = read_in(file_path)
    #seq_length = 16
    seq_length = 42 #150
    batch_size = 64
    encoder = character_ecode_decode(full_text)
    encoded_text = encoder.encode(full_text)
    output_dir = "out"
    #lr_schedules = ["ExponentialLR", "OneCycleLR" ]
    lr_schedule = "OneCycleLR"

    # training
    # Hyperparameter
    embed_size = len(encoder.vocab)
    #num_layers = [4] # [4, 6]
    #num_heads = [5, 7]
    n_heads = 7
    #net_expansion_factors = [4] # = [4, 6]
    num_epochs = 4
    #attention_types = ['dot_product', 'expressive']
    attention_type = 'dot_product'
    #learning_rates = [1e-2, 1e-3]
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #gammas = [0.9994, 0.9996, 1]
    gamma = 0.9999
    #momenta = [0.7, 0.8]
    #loss_criteria = [nn.CrossEntropyLoss(), nn.MSELoss()]
    loss_criterion = nn.CrossEntropyLoss()
    causal_padding_mask = torch.tril(torch.ones((seq_length, seq_length)))
    #masks = [causal_padding_mask]
    mask = causal_padding_mask



    # for quick testing: use only a small percentage of all data
    dataset = CharDataset(encoded_text[0:int(len(encoded_text) / 5)], seq_length)  # first 20%, first 1% of the data

    # todo: use full dataset: dataset = CharDataset(encoded_text, seq_length):
    # dataset = CharDataset(encoded_text, seq_length) # full dataset

    #dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # Split the dataset into 90% training and 10% test data
    train_size = int(0.9 * len(dataset))
    test_size = len(dataset) - train_size
    train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=True)
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    #ic(next(iter(train_dataloader))[0].size())
    #ic(test_dataloader.size())


    start = time.time()
    losses_dict = {}
    accuracy_dict = {}
    #for lr_schedule in lr_schedules:
    #    for loss_criterion in loss_criteria:
    #        for net_expansion_factor in net_expansion_factors:
    #            for mask in masks:
    #                for n_layers in num_layers:
    #                    for n_heads in num_heads:
    #                        for attention_type in attention_types:
    #                            for learning_rate in learning_rates:
    #                                for gamma in gammas:
    for net_expansion_factor, n_layers, learning_rate in [[4,4,0.01], [4,4,0.005], [4,4,0.003], [6,4,0.005], [4,8,0.005], [8,8,0.005], [8,12,0.005]]:
                                        alibi_positional_encoding_tensor = alibi_positional_encoding(n_heads, seq_length)
                                        model = Transformer(
                                            embedding_dim=embed_size,
                                            num_layers=n_layers,
                                            n_heads=n_heads,
                                            device=device,
                                            net_expansion_factor=net_expansion_factor,
                                            attention_type=attention_type,
                                            alibi_bias=alibi_positional_encoding_tensor,
                                            mask=mask
                                        ).to(device)
                                        # Modell, Loss und Optimizer
                                        optimizer = Adam(model.parameters(), lr=learning_rate)
                                        #if lr_schedule == "ExponentialLR":
                                        #    scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=gamma)  # verbose=True
                                        #if lr_schedule == "OneCycleLR":
                                            #if gamma == gammas[1]:
                                            #    continue
                                        total_steps = len(train_dataloader) * num_epochs  # Gesamtanzahl der Schritte
                                        scheduler = lr_scheduler.OneCycleLR(optimizer, max_lr=learning_rate, total_steps=total_steps)

                                        tag = f'{type(model).__name__},lr_schedule={lr_schedule}, loss_criterion={loss_criterion}, net_expansion_factor={net_expansion_factor}, n_layers={n_layers}, n_heads={n_heads}, attention_type={attention_type}, lr={learning_rate}, {f"gamma={gamma}, " if lr_schedule == "ExponentialLR" else ""} mask {"yes" if mask is not None else "no"}'
                                        print(tag)
                                        losses_dict[tag] = []
                                        accuracy_dict[tag] = []

                                        best = 0
                                        for epoch in range(1, num_epochs + 1):
                                            #train_dat_loader, optimizer, loss_criterion, alibi_bias = alibi_positional_encoding_tensor, mask = mask, scheduler = scheduler
                                            train_one_epoch(train_dataloader,
                                                            optimizer,
                                                            loss_criterion,
                                                            scheduler = scheduler)
                                            accuracy, loss = test(test_dataloader,
                                                                  loss_criterion)
                                            losses_dict[tag].append(loss)
                                            accuracy_dict[tag].append(accuracy)
                                            if accuracy > best:
                                                best = accuracy
                                        print('Höchste erreichte Genauigkeit: ', best)
                                        torch.save(model.state_dict(), f"{output_dir}/{tag}.pt")

    end = time.time()
    print('benötigte Zeit: ', end - start, '\n')

    losses_df = pd.DataFrame.from_dict(losses_dict)
    accuracy_df = pd.DataFrame.from_dict(accuracy_dict)
    losses_df.to_csv("loss.csv")
    accuracy_df.to_csv("accuracy.csv")
    #probabilities = torch.softmax(logits, dim=-1)
