from training import alibi_positional_encoding
import torch
import torch.nn.functional as F
from transformer import Transformer
#from training import character_ecode_decode, read_in
from train_final_model import character_ecode_decode, read_in

# torch.cuda.empty_cache()
# torch.cuda.reset_peak_memory_stats()


class BeamSearcher:
    def __init__(self, model, embedding_dimension, prediction_length, beam_width, max_candidates):
        self.model = model.to(device)
        self.device = device
        self.embedding_dimension = embedding_dimension
        self.sequence_candidates = None
        self.sequence_candidate_probabilities = None
        self.prediction_sequence_length = prediction_length
        self.beam_width = beam_width
        self.max_candidates = max_candidates

    def calculate_and_update_candidates(self, new_tokens, new_token_probabilities):
        new_tokens = new_tokens.view(-1, 1, self.embedding_dimension)
        # remove first token in each sequence and repeat each sequence beam_width times:
        expanded_batch = self.sequence_candidates[:, 1:].repeat_interleave(self.beam_width, dim=0)
        # add new tokens to expanded_batch:
        new_sequences = torch.cat((expanded_batch, new_tokens), dim=1)
        # update sequence_candidates and sequence_candidate_probabilities
        self.sequence_candidates = new_sequences
        self.sequence_candidate_probabilities = ( self.sequence_candidate_probabilities.repeat_interleave(self.beam_width, dim=0).to(device) * new_token_probabilities.view(-1).to(device)
        )
    def get_top_k_predictions(self, logits):
        probs = F.softmax(logits, dim=-1) #logits -> probabilities of predicted token
        #probs = F.log_softmax(logits, dim=-1)  # Log-probabilities, if wanted
        return torch.topk(probs, self.beam_width)

    def prune_beams(self):
        new_num_of_candidates = self.max_candidates // self.beam_width
        if new_num_of_candidates >= self.sequence_candidates.shape[0]:
            return
        new_sequence_candidate_indeces = torch.topk(self.sequence_candidate_probabilities, k=new_num_of_candidates).indices
        self.sequence_candidates = self.sequence_candidates[new_sequence_candidate_indeces]
        self.sequence_candidate_probabilities = self.sequence_candidate_probabilities[new_sequence_candidate_indeces]

    def do_search(self, embedded_input_batch):
        embedded_input_batch = embedded_input_batch.to(self.device)
        assert embedded_input_batch.shape[0] == 1, "embedded_input_batch shall contain only one sequence, but batch dimesnsion shall be provided"
        assert embedded_input_batch.shape[1] >= self.prediction_sequence_length, "prediction_sequence_length must be greater or equal than input sequence"
        self.sequence_candidates = embedded_input_batch
        # start with probability 1 for each sequence
        self.sequence_candidate_probabilities = torch.ones(len(embedded_input_batch))  # torch.tensor([1., 2.])

        for _ in range(self.prediction_sequence_length):
            num_candidates = self.sequence_candidates.shape[0]
            if num_candidates * self.beam_width > self.max_candidates:
                self.prune_beams()
            logits_last_token = self.model(self.sequence_candidates)[:, -1, :]
            top_k_probs, top_k_indices = self.get_top_k_predictions(logits_last_token)
            next_token_candidates = F.one_hot(top_k_indices, num_classes=self.embedding_dimension)
            self.calculate_and_update_candidates(next_token_candidates, top_k_probs)


if __name__ == "__main__":

    # text encodeing
    file_path = "goe_full.txt"
    full_text = read_in(file_path)
    encoder = character_ecode_decode(full_text)
    encoded_text = encoder.encode(full_text)

    n_heads =8
    #seq_length = 16
    #seq_length = 100
    seq_length = 256
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    causal_padding_mask = torch.tril(torch.ones((seq_length, seq_length)))
    alibi_positional_encoding_tensor = alibi_positional_encoding(n_heads, seq_length)
    model = Transformer(
        embedding_dim=80, #embedding_dim=70,
        num_layers=12, #num_layers=4,
        n_heads=n_heads, #n_heads=7,
        device=device,
        net_expansion_factor=4,
        attention_type='dot_product',
        alibi_bias=alibi_positional_encoding_tensor,
        mask=causal_padding_mask
    )

    # load weights
    model.load_state_dict(torch.load("out/run1/Transformer,lr_schedule=OneCycleLR, loss_criterion=CrossEntropyLoss(), net_expansion_factor=4, n_layers=12, n_heads=8, attention_type=dot_product, lr=0.0005, OneCycleLR, mask yes.pt", map_location=device))

    searcher = BeamSearcher(
        model = model,
        embedding_dimension = 80, #embedding_dim=70,
        prediction_length = 60,
        beam_width = 2,
        max_candidates = 8
    )

    #input_text = "Bitte keine drei"
    #input_text = " Sag mir einen S"
    input_text = "Dies ist ein exakt einhundert Zeichen langer Text, der genau die gewünschte Länge einhält. Perfekt! "
    input_text = " Des Lebens Fluss strömt ewig fort, in Licht und Schatten wechselnd, gleich dem wandelnden Geschick."
    input_text = "Des Lebens Wogen steigen und sinken, ein ewiges Streben, ein flüchtiges Hoffen, gleich dem Wind, der durch kahle Zweige fährt, doch nimmer ruht; so irrt der Mensch, von Sehnsucht getrieben, vom Schicksal geführt, bis einst der Schleier fällt und Stille ihn"
    print(len(input_text))

    print("input_text: ", input_text)
    #torch.tensor(bytearray(vocabulary_string, encoding), dtype=torch.int)
    encoded_text = torch.tensor([encoder.encode(input_text)], dtype=torch.int64)
    input_batch = model.one_hot_encode(encoded_text)

    searcher.do_search(input_batch)
    candidate_ranking = searcher.sequence_candidate_probabilities
    best_candidate = searcher.sequence_candidates[torch.argmax(candidate_ranking)]
    decoded_text = encoder.decode(model.one_hot_decode(best_candidate))
    prediction_beam_search = decoded_text[-(searcher.prediction_sequence_length):]
    print("prediction: ", prediction_beam_search)

    #print(encoded_text)

